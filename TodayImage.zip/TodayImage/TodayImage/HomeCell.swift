
import UIKit

class HomeCell: UICollectionViewCell {
    
    /* UIView */
    @IBOutlet weak var viewMain: UIView!
    
    /* ImageView */
    @IBOutlet weak var imgCategory: UIImageView!
    
    /* Label */
    @IBOutlet weak var lblName: UILabel!
}
